## ---- echo = FALSE, message = FALSE--------------------------------------
knitr::opts_chunk$set(collapse = T, comment = "#>")
library(binomial)
library(ggplot2)

## ------------------------------------------------------------------------
bin_choose(n = 5, k = 2)

## ------------------------------------------------------------------------
#to get probabilities about the 2 successes in 5 random trials performed under probability of 50%
bin_probability(success = 2, trials = 5, prob = 0.5)

## ------------------------------------------------------------------------
#to create a data frame with probability distribution
dis1 <- bin_distribution(trials = 5, prob = 0.5)
dis1

## ------------------------------------------------------------------------
#to get the probability histogram
plot(dis1)

## ------------------------------------------------------------------------
#to create a data frame with probability distribution and cumulative distribution
dis2 <- bin_cumulative(trials = 5 ,prob = 0.5)
dis2

## ------------------------------------------------------------------------
# plotting binomial cumulative distribution
plot(dis2)

## ------------------------------------------------------------------------
bin1 <- bin_variable(trials = 10, p = 0.3)
binsum1 <- summary(bin1)
binsum1

## ------------------------------------------------------------------------
#To get the mean
bin_mean(trials = 10, prob = 0.3)
#To get the variance
bin_variance(trials = 10, prob = 0.3)
#To get the mode
bin_mode(trials = 10, prob =0.3)
#To get the skewness
bin_skewness(trials = 10, prob = 0.3)
#To get the kurtosis
bin_kurtosis(trials = 10, prob = 0.3)

